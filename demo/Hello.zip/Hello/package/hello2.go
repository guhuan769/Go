package hello2

import (
	"fmt"
}

//小写函数名为私有 大写 为公有
func F2() {
	fmt.Println("F2")
}
